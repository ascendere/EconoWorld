import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './page/dashboard/dashboard.component';
import { HomeClientComponent } from '../client/econotest/home/home-client.component';
import { EconoPlayComponent } from '../client/econopley/econopley.component';
import { Econopley1Component } from '../client/econopley/econopley1/econopley1.component';
import { EconoNewsComponent } from '../client/econonew/econonew.component';
import { EconoBookComponent } from '../client/econobook/econobook.component';
import { Econobook1Component } from '../client/econobook/econobook1/econobook1.component';
import { EconoDataComponent } from '../client/econodata/econodata.component';
import { EconoBotComponent } from '../client/econobot/econobot.component';
import { EconoVideosComponent } from '../client/econovideos/econovideos.component';

const routes: Routes = [
  { path: '', component: DashboardComponent },
  { path: 'econotest', component: HomeClientComponent },
  { path: 'econoplay', component: EconoPlayComponent },
  { path: 'econopley1', component: Econopley1Component },
  { path: 'econonews', component: EconoNewsComponent },
  { path: 'econobook', component: EconoBookComponent },
  { path: 'econobook1', component: Econobook1Component },
  { path: 'econodata', component: EconoDataComponent },
  { path: 'econobot', component: EconoBotComponent },
  { path: 'econovideos', component: EconoVideosComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LandingRoutingModule { }
