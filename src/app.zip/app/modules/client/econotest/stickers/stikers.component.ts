import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { StickersService } from 'src/app/services/stickers.service';

@Component({
  selector: 'app-stikers',
  templateUrl: './stikers.component.html',
  styleUrls: ['./stikers.component.scss'],
})
export class StikersComponent implements OnInit, OnDestroy {
  user: any;
  stickers: any[] = [];
  selectedThematicId: string | null = null;
  selectedSticker: any;
  showSelectedSticker: boolean = false;
  totalStickers: number = 0;
  isFlipped: boolean = false;
  private unsubscribe$ = new Subject<void>();

  // Paginación
  currentPage: number = 1;
  stickersPerPage: number = 6;
  isPageTurningNext: boolean = false;
  isPageTurningPrev: boolean = false;

  constructor(
    private authService: AuthService,
    private stickersService: StickersService
  ) {}

  ngOnInit(): void {
    this.authService.currentUserObservable
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((user) => {
        if (user && user.uid) {
          this.user = user;
          this.loadUserStickers(user.uid);
          this.currentPage = 1;
        } else {
          this.user = null;
          this.stickers = [];
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  loadUserStickers(userId: string): void {
    this.stickersService
      .getUserStickers(userId)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe(
        (data) => {
          if (data && data.length > 0) {
            const groupedStickers = data.reduce((acc, sticker) => {
              const thematicId = sticker.thematicId;
              if (!acc[thematicId]) acc[thematicId] = [];
              acc[thematicId].push(sticker);
              return acc;
            }, {} as any);

            this.stickers = Object.keys(groupedStickers).map((thematicId) => ({
              thematicId,
              stickers: groupedStickers[thematicId],
            }));

            this.totalStickers = data.length;

            // Selecciona la primera temática por defecto
            if (this.stickers.length > 0) {
              this.selectedThematicId = this.stickers[0].thematicId;
            }
          } else {
            this.stickers = [];
            this.totalStickers = 0;
          }
        },
        (error) => {
          console.error('Error al cargar los stickers:', error);
          this.stickers = [];
          this.totalStickers = 0;
        }
      );
  }

  getFilteredStickers(): any[] {
    if (this.selectedThematicId) {
      const thematic = this.stickers.find(t => t.thematicId === this.selectedThematicId);
      return thematic?.stickers || [];
    } else {
      return this.stickers.flatMap(t => t.stickers || []);
    }
  }

  getCurrentPageStickers(): any[] {
    const allStickers = this.getFilteredStickers();
    const startIndex = (this.currentPage - 1) * this.stickersPerPage;
    return allStickers.slice(startIndex, startIndex + this.stickersPerPage);
  }

  getTotalPages(): number {
    const allStickers = this.getFilteredStickers();
    return Math.ceil(allStickers.length / this.stickersPerPage);
  }

  getCollectedStickerCount(): number {
    return this.getFilteredStickers().length;
  }

  async nextPage(): Promise<void> {
    if (this.currentPage < this.getTotalPages() && !this.isPageTurningNext) {
      this.isPageTurningNext = true;
      const pageElement = document.querySelector('.page') as HTMLElement;
      pageElement?.classList.add('turning');
      await new Promise((resolve) => setTimeout(resolve, 600));
      this.currentPage++;
      pageElement?.classList.remove('turning');
      this.isPageTurningNext = false;
    }
  }

  async prevPage(): Promise<void> {
    if (this.currentPage > 1 && !this.isPageTurningPrev) {
      this.isPageTurningPrev = true;
      const pageElement = document.querySelector('.page') as HTMLElement;
      pageElement?.classList.add('turning-back');
      await new Promise((resolve) => setTimeout(resolve, 600));
      this.currentPage--;
      pageElement?.classList.remove('turning-back');
      this.isPageTurningPrev = false;
    }
  }

  selectThematicId(thematicId: string | null): void {
    this.selectedThematicId = thematicId === 'null' ? null : thematicId;
    this.currentPage = 1;
  }

  capitalizeFirstLetter(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  showSticker(sticker: any): void {
    this.selectedSticker = sticker;
    this.showSelectedSticker = true;
    this.isFlipped = false;
  }

  hideSticker(): void {
    this.selectedSticker = null;
    this.showSelectedSticker = false;
  }

  flipCard(): void {
    this.isFlipped = !this.isFlipped;
  }
}
