import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
    selector: 'app-dashboard',
    templateUrl: './econobook.component.html',
    styleUrls: ['./econobook.component.scss']
})
export class EconoBookComponent {

  constructor(private router: Router) {}

  iniciar(): void {
    // Redirige a la pantalla de temáticas
    this.router.navigate(['/econobook']);
  }
}