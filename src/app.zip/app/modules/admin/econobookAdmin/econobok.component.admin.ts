import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LibrosService } from './libros.service'; // Asegúrate de ajustar el path si cambia

@Component({
  selector: 'app-econobook-admin',
  templateUrl: './econobok.component.admin.html',
  styleUrls: ['./econobok.component.admin.scss']
})
export class EconobookAdminComponent implements OnInit {
  libroForm!: FormGroup;

  portadaPreview: string | ArrayBuffer | null = null;
  archivoPDF: File | null = null;

  portadaUrl: string = '';
  pdfUrl: string = '';

  nivelRecomendacion = 0;

  constructor(
    private fb: FormBuilder,
    private librosService: LibrosService
  ) {}

  ngOnInit(): void {
    this.libroForm = this.fb.group({
      titulo: ['', Validators.required],
      autor: ['', Validators.required],
      editorial: ['', Validators.required],
      anio: ['', [Validators.required, Validators.pattern(/^\d{4}$/)]],
      descripcion: ['', Validators.required],
      estado: this.fb.group({
        borrador: [false],
        programarPublicacion: [false]
      }),
      opciones: this.fb.group({
        destacada: [false],
        comentarios: [false],
        boletin: [false]
      })
    });
  }

  async onPortadaSelected(event: any): Promise<void> {
    const file: File = event.target.files[0];
    if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
      const reader = new FileReader();
      reader.onload = () => (this.portadaPreview = reader.result);
      reader.readAsDataURL(file);

      try {
        this.portadaUrl = await this.librosService.subirArchivo(file, 'portadas');
      } catch (error) {
        console.error('Error al subir la portada:', error);
      }
    }
  }

  async onPdfSelected(event: any): Promise<void> {
    const file: File = event.target.files[0];
    if (file && file.type === 'application/pdf') {
      this.archivoPDF = file;

      try {
        this.pdfUrl = await this.librosService.subirArchivo(file, 'pdfs');
      } catch (error) {
        console.error('Error al subir el PDF:', error);
      }
    }
  }

  setRecomendacion(nivel: number): void {
    this.nivelRecomendacion = nivel;
  }

  eliminarPortada(): void {
    this.portadaPreview = null;
    this.portadaUrl = '';
  }

  eliminarPDF(): void {
    this.archivoPDF = null;
    this.pdfUrl = '';
  }

  guardar(): void {
    if (this.libroForm.valid && this.portadaUrl && this.pdfUrl) {
      const libro = {
        ...this.libroForm.value,
        portadaUrl: this.portadaUrl,
        archivoPdfUrl: this.pdfUrl,
        recomendacion: this.nivelRecomendacion,
        creadoEn: new Date()
      };

      console.log('Libro listo para guardar:', libro);
      // Aquí se conectará a Firestore en el siguiente paso
    } else {
      console.warn('Formulario inválido o archivos faltantes');
      this.libroForm.markAllAsTouched();
    }
  }

  guardarComoBorrador(): void {
    console.log('Guardar como borrador...');
    // Lógica similar a guardar(), pero con estado.borrador = true
  }

  publicar(): void {
    console.log('Publicar libro...');
    // Lógica final de validación + guardado
  }
}
