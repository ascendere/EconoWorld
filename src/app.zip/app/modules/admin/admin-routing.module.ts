// src/app/modules/admin/admin-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ThematicsComponent } from './econotestAdmin/components/thematics/thematics.component'; // ✅ Ruta base

const routes: Routes = [
  {
    path: '',
    redirectTo: 'tematicas', // ✅ Redirigir a 'tematicas'
    pathMatch: 'full'
  },
  {
    path: 'tematicas',
    component: ThematicsComponent
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
