import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanMatch,
  Route,
  UrlSegment,
  UrlTree,
  RouterStateSnapshot,
  Router,
} from '@angular/router';
import { Observable, map, tap } from 'rxjs';
import { AuthService } from '../auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanMatch, CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  // Verifica si el usuario está autenticado
  private checkAuthStatus(): Observable<boolean> {
    return this.authService.checkAuthentication().pipe(
      tap((isAuthenticated) => {
        if (!isAuthenticated) {
          // Si no está autenticado, redirigir a la página de inicio o login
          this.router.navigate(['/login']);
        }
      })
    );
  }

  // Verifica si el usuario tiene el rol adecuado
  private checkUserRole(expectedRole: string): Observable<boolean> {
    return this.authService.getUser().pipe(
      tap((user) => {
        if (!user || user.role !== expectedRole) {
          // Si el rol no es el esperado, redirige a una página por defecto o de error
          this.router.navigate(['/error']); // O puedes redirigir a una página de acceso denegado
        }
      }),
      map((user) => !!user && user.role === expectedRole) // Devuelve true si tiene el rol adecuado
    );
  }

  // Método para coincidir con rutas (canMatch) - solo verifica si está autenticado
  canMatch(
    route: Route,
    segments: UrlSegment[]
  ): boolean | Observable<boolean> {
    return this.checkAuthStatus();
  }

  // Método para activar rutas (canActivate) - verifica autenticación y rol si es necesario
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | Observable<boolean> {
    const expectedRole = route.data['expectedRole']; // Obtiene el rol esperado de los datos de la ruta
    if (expectedRole) {
      // Si se espera un rol en la ruta, verificar si el usuario tiene el rol esperado
      return this.checkUserRole(expectedRole);
    } else {
      // Si no se define un rol esperado en la ruta, permitir el acceso
      return this.checkAuthStatus(); // Solo verifica si está autenticado
    }
  }
}
