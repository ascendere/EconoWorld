import { Component, ElementRef, OnDestroy, ViewChild, OnInit } from '@angular/core';
import { Router, Event, NavigationEnd } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, OnDestroy {
  isOpen = false;
  isAuthenticated = false;
  userName = '';
  userRole = '';
  redirectAfterLogin = '/';
  currentRoute: string = '';
  tituloActual = 'EconoWorld';
  esLanding: boolean = false;

  @ViewChild('loginModal') loginModal!: ElementRef;

  routeTitles: { [key: string]: string } = {
    '/econotest': 'EconoTest',
    '/econoplay': 'EconoPlay',
    '/econopley1': 'EconoPlay',
    '/econonews': 'EconoNews',
    '/econobook': 'EconoBook',
    '/econobot': 'EconoBot',
    '/econobook1': 'EconoBook',
    '/tematica': 'EconoTest',
    '/econovideos': 'EconoVideos',
    '/': 'EconoWorld',
  };

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.authService.checkAuthentication().subscribe((authenticated) => {
      this.isAuthenticated = authenticated;
      if (authenticated) this.loadUser();
    });

    this.authService.loginModalTrigger$.subscribe((redirectTo) => {
      if (redirectTo) {
        this.openLoginModal(redirectTo);
        this.authService.clearLoginModalTrigger();
      }
    });

    this.router.events
      .pipe(filter((event: Event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.currentRoute = event.urlAfterRedirects;
        const match = Object.keys(this.routeTitles).find((key) =>
          this.currentRoute.startsWith(key)
        );
        this.tituloActual = match ? this.routeTitles[match] : 'EconoWorld';
        this.esLanding = this.currentRoute === '/';
      });
  }

  ngOnDestroy(): void {
    this.authService.ngOnDestroy();
  }

  private loadUser(): void {
    this.authService.getUser().subscribe((user) => {
      if (user) {
        this.userName = user.name || user.givenName || '';
        this.userRole = user.role || '';

        const destino = this.getRedirectUrl(this.currentRoute);
        this.router.navigate([destino]);

        this.closeLoginModal();
        this.closeAuthPopup();
      }
    });
  }

  openLoginModal(redirectTo: string = '/econotest'): void {
    this.redirectAfterLogin = redirectTo;
    if (this.loginModal?.nativeElement) {
      this.loginModal.nativeElement.style.display = 'block';
    }
  }

  closeLoginModal(): void {
    if (this.loginModal?.nativeElement) {
      this.loginModal.nativeElement.style.display = 'none';
    }
  }

  signIn(provider: string): void {
    const signInMethod = provider === 'ms'
      ? this.authService.signInWithMicrosoft()
      : this.authService.signInWithGoogle();

    signInMethod
      .then((user) => {
        if (user) {
          this.userName = user.name || user.givenName || '';
          this.userRole = user.role || '';

          const destino = this.getRedirectUrl(this.redirectAfterLogin);
          this.router.navigate([destino]);

          this.closeLoginModal();
          this.closeAuthPopup();
        }
      })
      .catch((error) => console.error('Error al iniciar sesión:', error));
  }

  signOut(): void {
    this.authService.signOut();
    this.isAuthenticated = false;
    this.userName = '';
    this.userRole = '';
    this.router.navigate(['/']);
  }

  private getRedirectUrl(originalPath: string): string {
    if (this.userRole === 'admin') {
      // Excluir redirección para estas rutas
      const excepciones = ['/econotest', '/econovideos'];
      const coincideExcepcion = excepciones.some(path => originalPath.startsWith(path));
      if (coincideExcepcion) return originalPath;

      // Si es admin y la ruta no es una excepción, entonces redirige al prefijo admin
      if (originalPath.startsWith('/admin')) return originalPath;

      // Si no es una ruta de admin, agrega el prefijo /admin
      const cleanPath = originalPath.startsWith('/') ? originalPath.slice(1) : originalPath;
      return `/admin/${cleanPath}`;
    }

    // Si no es admin, no se hace ningún cambio en la ruta
    return originalPath;
  }

  private closeAuthPopup(): void {
    if (window.opener) {
      window.opener.postMessage({ type: 'auth_success' }, '*');
    }
  }

  navigateToHome(): void {
    this.router.navigate([this.getRedirectUrl('/tematica')]);
  }

  navigateToStickers(): void {
    this.router.navigate([this.getRedirectUrl('/tematica/cromos')]);
  }

  navigateToAdmin(): void {
    this.router.navigate(['/admin']);
  }

  public navegar(ruta: string): void {
    this.router.navigate([this.getRedirectUrl(ruta)]);
  }

  get mostrarNombre(): boolean {
    return this.isAuthenticated && (
      this.currentRoute.startsWith('/econotest') ||
      this.currentRoute.startsWith('/tematica')
    );
  }

  get mostrarAlbum(): boolean {
    return this.isAuthenticated &&
      this.currentRoute.startsWith('/tematica/') &&
      !this.currentRoute.includes('/cromos');
  }

  isRutaGeneral(): boolean {
    const rutas = [
      '/econoplay',
      '/econonews',
      '/econobook',
      '/econobot',
      '/econobook1',
      '/econopley1',
      '/tematica',
      '/econovideos'
    ];
    return rutas.some(ruta => this.currentRoute.startsWith(ruta)) && this.isAuthenticated;
  }
}
