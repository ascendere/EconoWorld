import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './services/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./modules/landing/landing.module').then(m => m.LandingModule),
    canActivate: [],
  },
  {
    // ruta client
    path: 'tematica',
    loadChildren: () => import('./modules/client/client.module').then(m => m.ClientModule),
    canActivate: [ AuthGuard ],
    data: { expectedRole: '' } // Define el rol esperado como 'admin'

  },
  {
     // ruta administrador
    path: 'admin',
    loadChildren: () => import('./modules/admin/admin.module').then(m => m.AdminModule),
    canActivate: [ AuthGuard ],
    data: { expectedRole: 'admin' } // Define el rol esperado como 'admin'

  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
